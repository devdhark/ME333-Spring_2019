function client(port)
%   provides a menu for accessing PIC32 motor control functions
%
%   client(port)
%
%   Input Arguments:
%       port - the name of the com port.  This should be the same as what
%               you use in screen or putty in quotes ' '
%
%   Example:
%       client('/dev/ttyUSB0') (Linux/Mac)
%       client('COM3') (PC)
%
%   For convenience, you may want to change this so that the port is hardcoded.
   
% Opening COM connection
if ~isempty(instrfind)
    fclose(instrfind);
    delete(instrfind);
end

fprintf('Opening port %s....\n',port);


% settings for opening the serial port. baud rate 230400, hardware flow control
% wait up to 120 seconds for data before timing out
mySerial = serial(port, 'BaudRate', 230400, 'FlowControl', 'hardware','Timeout',120); 
% opens serial connection
fopen(mySerial);
% closes serial port when function exits
clean = onCleanup(@()fclose(mySerial));                                 

has_quit = false;
% menu loop
while ~has_quit
    fprintf('PIC32 MOTOR DRIVER INTERFACE\n\n');
    % display the menu options; this list will grow
    fprintf('a: Read current sensor (ADC counts)    b: Read current sensor (mA)\n');
    fprintf('c: Read encoder (counts)               d: Read encoder (deg)\n');
    fprintf('e: Reset encoder                       f: Set PWM (-100 to 100)\n');
    fprintf('g: Set current gains                   h: Get current gains\n');
    fprintf('i: Set position gains                  j: Get position gains \n');
    fprintf('k: Test current trajectory             l: Go to angle (deg)\n');
    fprintf('m: Load step trajectory                n: Load cubic trajectory\n');
    fprintf('o: Execute trajectory                  p: Unpower the motor\n');
    fprintf('q: Quit client                         r: Get mode');

    % read the user's choice
    selection = input('\nENTER COMMAND: ', 's');
     
    % send the command to the PIC32
    fprintf(mySerial,'%c\n',selection);
    
    % take the appropriate action
    switch selection
        case 'a'
            n = fscanf(mySerial,'%d');   % get the incremented number back
            fprintf('Current sensor value (ADC counts): %d\n',n);     % print it to the screen
        case 'b'
            n = fscanf(mySerial,'%d');   % get the incremented number back
            fprintf('Current sensor value (mA): %d\n',n);     % print it to the screen
        case 'c'
            n = fscanf(mySerial,'%d');   % get the incremented number back
            fprintf('Motor angle (encoder counts): %d\n',n);     % print it to the screen
        case 'd'
            n = fscanf(mySerial,'%d');   % get the incremented number back
            fprintf('Motor angle (degrees): %d\n',n);     % print it to the screen
        case 'e'
            fprintf('The encoder has been reset\n');
        case 'f'
            n = input('Enter Duty cycle of the PWM (in %): '); % get the number to send
            fprintf(mySerial, '%d\n',n); % send the number
        case 'g'
            n = input('Enter the Proportional gain: '); % get the number to send
            fprintf(mySerial, '%f\n',n); % send the number
            n = input('Enter the Integral gain: '); % get the number to send
            fprintf(mySerial, '%f\n',n); % send the number
        case 'h'
            n = fscanf(mySerial,'%f');   % get the incremented number back
            fprintf('Proportional gain, Kp = %f\n',n);     % print it to the screen
            n = fscanf(mySerial,'%f');   % get the incremented number back
            fprintf('Integral gain, Ki = %f\n',n);     % print it to the screen
        case 'i'
            n = input('Enter the Proportional gain: '); % get the number to send
            fprintf(mySerial, '%f\n',n); % send the number
            n = input('Enter the Integral gain: '); % get the number to send
            fprintf(mySerial, '%f\n',n); % send the number
            n = input('Enter the Derivative gain: '); % get the number to send
            fprintf(mySerial, '%f\n',n); % send the number
        case 'j'
            n = fscanf(mySerial,'%f');   % get the incremented number back
            fprintf('Proportional gain, Kp = %f\n',n);     % print it to the screen
            n = fscanf(mySerial,'%f');   % get the incremented number back
            fprintf('Integral gain, Ki = %f\n',n);     % print it to the screen
            n = fscanf(mySerial,'%f');   % get the incremented number back
            fprintf('Derivative gain, Kd = %f\n',n);     % print it to the screen
        case 'k'
            read_plot_matrix(mySerial);
        case 'l'
            n = input('Enter the desired angle(in deg): '); % get the number to send
            fprintf(mySerial, '%d\n',n); % send the number
        case 'm'
            N = input('Enter the number of reference inputs: ');
            fprintf(mySerial, '%d\n',N); % send the number
            A = input('Enter the trajectory parameters (N by 2 matrix): '); % get the number to send
            for i = 1:N                     % send the array entered by the user
               n = A(i,2);
               fprintf(mySerial, '%d\n',n);
            end
            ref = genRef(A, 'step');
        case 'n'
            N = input('Enter the number of reference inputs: ');
            fprintf(mySerial, '%d\n',N);        % send the number
            A = input('Enter the trajectory parameters (N by 2 matrix): '); % get the number to send
            for i = 1:N                         % send the array entered by the user
               n = A(i,2);
               fprintf(mySerial, '%d\n',n);
            end
            ref = genRef(A, 'cubic');
        case 'o'
            motor_angle_plot(mySerial);
        case 'p'
                                         % unpower the motor
        case 'q'
            has_quit = true;             % exit client
        case 'r'
            n = fscanf(mySerial,'%d');   % get the incremented number back
            fprintf('Possible operating modes :\n 1. IDLE\t 2. PWM\n 3. ITEST\t 4. HOLD \n 5. Track\n');     % print it to the screen
            fprintf('Current operating mode is : %d\n',n);     % print it to the screen
            %n = input('Enter the new operating mode: '); % get the number to send
            %fprintf(mySerial,'%d\n',n); % send the number  
        otherwise
            fprintf('Invalid Selection %c\n', selection);
    end
end

end
