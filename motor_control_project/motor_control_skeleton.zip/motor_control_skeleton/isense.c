#include "NU32.h"
#include "isense.h"

unsigned int adc_sample_convert(int pin) { // sample & convert the value on the given
                                           // adc pin the pin should be configured as an
                                           // analog input in AD1PCFG
    unsigned int elapsed = 0, finish_time = 0;
    AD1CHSbits.CH0SA = pin;                // connect chosen pin to MUXA for sampling
    AD1CON1bits.SAMP = 1;                  // start sampling
    elapsed = _CP0_GET_COUNT();
    finish_time = elapsed + SAMPLE_TIME;
    while (_CP0_GET_COUNT() < finish_time) {
      ;                                   // sample for more than 250 ns
    }
    AD1CON1bits.SAMP = 0;                 // stop sampling and start converting
    while (!AD1CON1bits.DONE) {
      ;                                   // wait for the conversion process to finish
    }
    return ADC1BUF0;                      // read the buffer with the result
}

void adc_init(void) {
  AD1PCFGbits.PCFG0 = 0;                 // AN0 is an adc pin
  AD1CON3bits.ADCS = 2;                   // ADC clock period is Tad = 2*(ADCS+1)*Tpb =
                                          //                           2*3*12.5ns = 75ns
  AD1CON1bits.ADON = 1;                   // turn on A/D converter
}

int adc_counts(void) {
  int average_adc, sum_adc = 0, i;
  for(i = 0; i<10 ; i++) {            // average 10 adc counts from analog pin
     sum_adc = sum_adc + adc_sample_convert(0);
  }
  average_adc = sum_adc/10;
  return average_adc;
}

signed int adc_current_count(void) {
  int milliamps;
  milliamps = 1.337 * adc_counts() - 686.09;  // by linear regression of data points
  return milliamps;
}
