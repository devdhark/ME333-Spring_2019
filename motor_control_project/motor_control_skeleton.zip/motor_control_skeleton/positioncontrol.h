#ifndef helper__H__
#define helper__H__

#define BUF_SIZE 200

volatile float KP = 0, KI = 0, KD = 0;
volatile int THETA = 0;
volatile int eprev = 0, e_pos = 0, eint_pos = 0, u_pos = 0, unew_pos = 0, edot_pos = 0;
volatile int N = 0, ref_position[50], motor_angle[50];
volatile int i = 0;   // loop counter
char buffer[BUF_SIZE];

void positioncontrol_init(void);
void __ISR(_TIMER_4_VECTOR, IPL6SOFT) PositionController(void);
void set_position_gains(void);
void get_position_gains(void);
void get_position_angle(void);
void set_step_trajectories(void);
void set_cubic_trajectories(void);

#endif
