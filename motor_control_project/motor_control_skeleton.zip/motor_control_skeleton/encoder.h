#ifndef encoder__H__
#define encoder__H__

int encoder_counts(void);
int encoder_angle(void);
int encoder_reset(void);
void encoder_init(void);

#endif
