#include "NU32.h"          // config bits, constants, funcs for startup and UART
#include <stdio.h>
#include "encoder.h"
#include "utilities.h"
#include "isense.h"
#include "currentcontrol.h"
#include "positioncontrol.h"

// include other header files here

#define BUF_SIZE 200
#define NUMSAMPS 100      // number of points in waveform

extern volatile int MODE;   // MODE declared in utilities.h
extern volatile int DUTY;   // DUTY declared in currentcontrol.h
extern volatile signed int ref_current[NUMSAMPS];  // reference current(in mA)
extern volatile signed int act_current[NUMSAMPS];  // the actual measured current(in mA)
extern volatile int N, ref_position[50], motor_angle[50];  // motor angle trajectory w.r.t input angles
extern volatile int THETA;

int main()
{
  char buffer[BUF_SIZE];
  int i;          // loop counter
  NU32_Startup(); // cache on, min flash wait, interrupts on, LED/button init, UART init
  NU32_LED1 = 1;  // turn off the LEDs
  NU32_LED2 = 1;
  __builtin_disable_interrupts();
  encoder_init();               // in future, initialize modules or peripherals here
  MODE = 1;
  adc_init();
  currentcontrol_init();
  positioncontrol_init();
  __builtin_enable_interrupts();

  while(1)
  {
    NU32_ReadUART3(buffer,BUF_SIZE); // we expect the next character to be a menu command
    NU32_LED2 = 1;                   // clear the error LED
    switch (buffer[0]) {
      case 'a':
      {
        sprintf(buffer,"%d\n\r", adc_counts());
        NU32_WriteUART3(buffer);    // send adc counts to client
        break;
      }
      case 'b':
      {
        sprintf(buffer,"%d\n\r", adc_current_count());
        NU32_WriteUART3(buffer);    // send adc counts (in mA) to client
        break;
      }
      case 'c':
      {
        sprintf(buffer,"%d\n\r", encoder_counts());
        NU32_WriteUART3(buffer);    // send encoder count to client
        break;
      }
      case 'd':
      {
        sprintf(buffer,"%d\n\r", encoder_angle());     // send encoder angle to client
        NU32_WriteUART3(buffer);
        break;
      }
      case 'e':
      {
        encoder_reset();
        break;
      }
      case 'f':
      {
        MODE = 2;     // PWM mode (Here duty cycle becomes 0%)
        NU32_ReadUART3(buffer,BUF_SIZE);
        sscanf(buffer, "%d", &DUTY);
        break;
      }
      case 'g':
      {
        set_current_gains();
        break;
      }
      case 'h':
      {
        get_current_gains();
        break;
      }
      case 'i':
      {
        set_position_gains();
        break;
      }
      case 'j':
      {
        get_position_gains();
        break;
      }
      case 'k':
      {
        make_reference_current(0, 200);
        MODE = 3;
        sprintf(buffer,"%d\n\r", NUMSAMPS);
        NU32_WriteUART3(buffer);    // send the number of samples to client
        for(i = 0; i<NUMSAMPS; i++) {
          sprintf(buffer,"%d %d\n\r", ref_current[i], act_current[i]);
          NU32_WriteUART3(buffer);    // send current array to client for plotting
        }
        i = 0;
        break;
      }
      case 'l':
      {
        get_position_angle();   // desired position angle
        encoder_reset();      // encode resets for every new case
        ref_position[0] = THETA;
        MODE = 4;
        break;
      }
      case 'm':
      {
        set_step_trajectories();
        break;
      }
      case 'n':
      {
        set_cubic_trajectories();
        break;
      }
      case 'o':
      {
        encoder_reset();    // encode resets for every new case
        MODE = 5;
        while(MODE==5) {;} // waiting for the samples
        sprintf(buffer,"%d\n\r", N);
        NU32_WriteUART3(buffer);    // send the number of samples to client
        for(i = 0; i<N; i++) {
          sprintf(buffer,"%d %d\n\r", ref_position[i], motor_angle[i]);
          NU32_WriteUART3(buffer);    // send current array to client for plotting
        }
        i = 0;
        break;
      }
      case 'p':
      {
        MODE = 1;     // Unpowering the motor
        break;
      }
      case 'q':
      {
        MODE = 1;     // Set to IDLE mode when quiting.
        break;
      }
      case 'r':
      {
        get_operating_mode();
        //set_operating_mode();         // sets a new mode for the user, (not necessary)
        break;
      }
      default:
      {
        NU32_LED2 = 0;  // turn on LED2 to indicate an error
        break;
      }
    }
  }
  return 0;
}
