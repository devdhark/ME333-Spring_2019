#ifndef helper__H__
#define helper__H__

#define SAMPLE_TIME 10       // 10 core timer ticks = 250 ns

unsigned int adc_sample_convert(int pin);
void adc_init(void);
int adc_counts(void);
signed int adc_current_count(void);

#endif
