#ifndef helper__H__
#define helper__H__

#define BUF_SIZE 200
#define NUMSAMPS 100      // number of points in waveform

volatile int DUTY = 0;
volatile float P_GAIN = 0, I_GAIN = 0;
volatile signed int ref_current[NUMSAMPS];  // reference current(in mA)
volatile signed int act_current[NUMSAMPS];  // the actual measured current(in mA)
static volatile int u = 0, unew = 0, e = 0, eint = 0;
static int y = 0, i = 0;

char buffer[BUF_SIZE];

void currentcontrol_init(void);
void __ISR(_TIMER_2_VECTOR, IPL5SOFT) CurrentController(void);
void set_current_gains(void);
void get_current_gains(void);
void make_reference_current(int center, int A);

#endif
