#include "utilities.h"
#include <xc.h>

#define BUF_SIZE 200

char buffer[BUF_SIZE];

void get_operating_mode(void) {
  sprintf(buffer,"%d\n\r", MODE);
  NU32_WriteUART3(buffer);    // send current operating MODE to client
}
void set_operating_mode(void) {
  NU32_ReadUART3(buffer,BUF_SIZE);
  sscanf(buffer, "%d\n\r", &MODE);
}
