#include "NU32.h"
#include <stdio.h>
#include "positioncontrol.h"
#include "utilities.h"

void positioncontrol_init(void) {
  T4CONbits.TCKPS = 6;     // Timer4 prescaler N=64 (1:64)
  PR4 = 6249;              // period = (PR2+1) * N * 12.5 ns = 5000 us, 200 Hz
  TMR4 = 0;                // initial TMR2 count is 0
  T4CONbits.ON = 1;        // turn on Timer2
  IPC4bits.T4IP = 6;       // step 4
  IFS0bits.T4IF = 0;       // step 5
  IEC0bits.T4IE = 1;       // step 6
  TRISDbits.TRISD9 = 0;    // digital output pin
}

void __ISR(_TIMER_4_VECTOR, IPL6SOFT) PositionController(void) {  // INT step 1: the ISR
  LATDbits.LATD9 = !LATDbits.LATD9;
  if(MODE == 4) {       // HOLD
    e_pos = ref_position[i] - encoder_angle();
    eint_pos = eint_pos + e_pos;
    if (eint_pos > 500) {     // integrator anti-windup
      eint_pos = 500;
    }
    else if (eint_pos < -500) {
      eint_pos = -500;
    }
    edot_pos = e_pos - eprev;
    u_pos = KP*e_pos + KI*eint_pos + KD*edot_pos;
    eprev = e_pos;
  }
  if(MODE == 5) {        // TRACK
    e_pos = ref_position[i] - encoder_angle();
    eint_pos = eint_pos + e_pos;
    if (eint_pos > 500) {     // integrator anti-windup
      eint_pos = 500;
    }
    else if (eint_pos < -500) {
      eint_pos = -500;
    }
    edot_pos = e_pos - eprev;
    u_pos = KP*e_pos + KI*eint_pos + KD*edot_pos;
    eprev = e_pos;
    motor_angle[i] = encoder_angle();      // sent to client later for plotting
    if(i == N-1) {
      MODE = 4;
      i=0;
    }
    i++;
  }
  IFS0bits.T4IF = 0;        // clear interrupt flag
}

void set_position_gains(void) {
  NU32_ReadUART3(buffer,BUF_SIZE);
  sscanf(buffer, "%f\n\r", &KP);
  NU32_ReadUART3(buffer,BUF_SIZE);
  sscanf(buffer, "%f\n\r", &KI);
  NU32_ReadUART3(buffer,BUF_SIZE);
  sscanf(buffer, "%f\n\r", &KD);
}

void get_position_gains(void) {     // send the positions gains to client
  sprintf(buffer,"%f\n\r", KP);
  NU32_WriteUART3(buffer);
  sprintf(buffer,"%f\n\r", KI);
  NU32_WriteUART3(buffer);
  sprintf(buffer,"%f\n\r", KD);
  NU32_WriteUART3(buffer);
}

void get_position_angle(void) {
  NU32_ReadUART3(buffer,BUF_SIZE);
  sscanf(buffer, "%d\n\r", &THETA);
}

void set_step_trajectories(void) {
  int i;
  NU32_ReadUART3(buffer,BUF_SIZE);
  sscanf(buffer, "%d", &N);
  for(i = 0; i<N; i++) {
    NU32_ReadUART3(buffer,BUF_SIZE);
    sscanf(buffer, "%d", &ref_position[i]);
  }
}

void set_cubic_trajectories(void) {
  int i;
  NU32_ReadUART3(buffer,BUF_SIZE);
  sscanf(buffer, "%d", &N);
  for(i = 0; i<N; i++) {
    NU32_ReadUART3(buffer,BUF_SIZE);
    sscanf(buffer, "%d", &ref_position[i]);
  }
}
