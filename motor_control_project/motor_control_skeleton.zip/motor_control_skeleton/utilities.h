#ifndef encoder__H__
#define encoder__H__

volatile int MODE;

void get_operating_mode(void);
void set_operating_mode(void);

#endif
